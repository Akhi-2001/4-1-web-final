<?php
include 'crudconfig.php';


if(isset($_POST['upload'])){
    $Name = $_POST['name'];
    $Value= $_POST['value'];
    $Image = $_FILES['image'];
  $img_loc = $_FILES['image']['tmp_name'];
  $img_name = $_FILES['image']['name'];
  $img_des = "images/".$img_name;
  move_uploaded_file($img_loc,'images/'.$img_name);


  mysqli_query($con, "insert into product (Name, value, Image) VALUES ('$Name','$Value','$img_des')");
  header("location: crud1.php");

}
?>