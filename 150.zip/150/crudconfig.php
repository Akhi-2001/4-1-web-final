<?php
$con = mysqli_connect('localhost', 'root', '', 'akhi');
?>