<!DOCTYPE html>
<?php require_once("config.php"); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div class="container">
      <div class="row">
<?php
if(isset($_POST['signup']))
{
    extract($_POST);
    if(strlen($fname)<3)
    {
        $error[] = 'Please enter first name using 3 characters atleast';
    }
    if(strlen($fname)>20)
    {
        $error[] = 'Please enter first name using max 20 characters';
    }
    if(!preg_match("/^[A-Za-z _]*[A-Za-z ]+[A-Za-z _]*$/",$fname))
    {
        $error[] = 'Invalid entry first name. plz enter only letters----digit or special characters are not allowed';
    }

    if(strlen($lname)<3)
    {
        $error[] = 'Please enter last name using 3 characters atleast';
    }
    if(strlen($lname)>20)
    {
        $error[] = 'Please enter last name using max 20 characters';
    }
    if(!preg_match("/^[A-Za-z _]*[A-Za-z ]+[A-Za-z _]*$/",$lname))
    {
        $error[] = 'Invalid entry last name. plz enter only letters----digit or special characters are not allowed';
    }

    if(strlen($username)<3)
    {
        $error[] = 'Please enter user name using 3 characters atleast';
    }
    if(strlen($username)>30)
    {
        $error[] = 'Please enter user name using max 30 characters';
    }
    if(!preg_match("/^^[^0-9][a-z0-9]+([_-]?[a-z0-9])*$/",$username))
    {
        $error[] = 'Invalid entry for user name. plz enter lower case letters without any space and no
        number at the start............';
    }

    if(strlen($email)>30)
    {
        $error[] = 'Please enter user name using max 30 characters';
    }

    if($passwordConfirm == '')
    {
        $error[] = 'plz confirm the password';
    }

    if($password != $passwordConfirm)
    {
        $error[] = 'Passwords do not match';
    }

    if(strlen($password)<5)
    {
        $error[] = 'Password must be 6 characters long';
    }

    if(strlen($password)>20)
    {
        $error[] = 'Password: Max length 20 characters not allowed';
    }

    $sql = "select * from users where (username='$username' or email='$email');";
    $res=mysqli_query($dbConnect,$sql);
    if(mysqli_num_rows($res)>0)
    {
        $row=mysqli_fetch_assoc($res);
        if($username==$row['username'])
        {
            $error[] = 'UserName already Exists!!!';
        }
        if($email==$row['email'])
        {
            $error[] = 'Email already Exists!!!';
        }
    }

    if(!isset($error))
    {
        $date=date('d-m-y');
        $options=array("cost"=>4);
        $password=password_hash($password,PASSWORD_BCRYPT,$options);

        $result = mysqli_query($dbConnect,"INSERT into users 
        values('','$fname','$lname','$username','$email','$password','$date')");

        if($result)
        {
            $done=2;
        }
        else
        {
            $error[] = 'Failed: something went wrong';
        }
    }



}
?>
        <div class="col-sm-4">
            <?php
            if(isset($error))
            {
                foreach($error as $error)
                {
                    echo '<p class="errmsg">&#x26A0;'.$error.'</p>';
                }
            }
            ?>
        </div>
        <div class="col-sm-4">

    <?php if(isset($done))  
    { ?>
    <div class="successmsg"><span style="font-size:100px">&#9989;</span><br>
    You have registered successfully <br> <a href="login.php" style="color:#fff;">Login here </a></div>

    <?php } else {?>
        <div class="signup_form">
             <form action="" method="POST">  <!--same page action null and using post method data hold -->
           
     <div class="form-group">
    <label class="label_txt">First Name</label><br>
    <input type="text" class="form-control" name="fname" value="<?php if(isset($error)){echo $fname;}?>" required="">
    </div>

    <div class="form-group">
    <label class="label_txt">Last Name</label><br>
    <input type="text" class="form-control" value="<?php if(isset($error)){echo $lname;}?>" name="lname" required="">
    </div>

    <div class="form-group">
    <label class="label_txt">UserName</label><br>
    <input type="text" class="form-control" name="username" value="<?php if(isset($error)){echo $username;}?>" required="">
    </div>

    <div class="form-group">
    <label class="label_txt">Email</label><br>
    <input type="email" class="form-control" name="email" value="<?php if(isset($error)){echo $email;}?>" required="">
    </div>

    <div class="form-group">
    <label class="label_txt">Password</label><br>
    <input type="password" class="form-control" name="password" required="">
    </div>

    <div class="form-group">
    <label class="label_txt">Confirm Password</label><br>
    <input type="password" class="form-control" name="passwordConfirm" required="">
    </div>

    <button type="submit" name="signup" class="btn btn-primary btn-group-lg form_btn">SignUp</button>
    <p>Have an account? <a href="login.php">Log in</a> </p>
    <?php } ?>
</form>
</div>
</div>
<div class="col-sm-4">
</div>
</div>
</div>
     
    
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</html>