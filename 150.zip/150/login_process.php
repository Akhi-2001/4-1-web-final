<?php
   require_once("config.php");

   if(isset($_GET['sublogin']))
   {
    $login = $_GET['login_var'];
    $password = $_GET['password'];
    $query = "select * from users where (username='$login' OR email='$login')";
    $res = mysqli_query($dbConnect,$query);
    $numRows = mysqli_num_rows($res);
    if($numRows==1)
    {
        $row = mysqli_fetch_assoc($res);
        if(password_verify($password,$row['password']))
        {
            $_SESSION["login_sess"]="1";
            $_SESSION["login_email"]=$row['email'];
            header("location:crud1.php");
        }
        else{
            header("location:login.php?loginerror=".$login);
        }
    }
    else{
        header("location:login.php?loginerror=".$login);
    }
   }
?>