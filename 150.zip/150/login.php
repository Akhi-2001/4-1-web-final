<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
  <div class="container">
    <div class="row">
    <div class="col-sm-4">
        </div>
        <div class="col-sm-4">
          <div class="login_form">
            <?php
            if(isset($_GET['loginerror']))
            {
              $loginerror = $_GET['loginerror'];
            }
            if(!empty($loginerror))
            {
              echo '<p class="errmsg">Invalid login credentials, please try again...</p>';
            }
            ?>
        <form action="login_process.php" method="POST">
  <div class="form-group">
    <label for="exampleInputEmail1">Username or Email</label>
    <input type="text" name="login_var" value="<?php if(!empty($loginerror)){echo $loginerror;}?>" class="form-control">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="password" class="form-control">
  </div>
  <button type="submit" name="sublogin" class="btn btn-primary form_btn">Login</button>
</form>

<p style="font-size: 12px; text-align:center; margin-top: 10px;"><a href="
forgot-password.php" style="color: #00376b;"> Forgot Password? </a> </p>
<br>
<p>Don't have an account? <a href="signup.php">Sign up</a> </p>
</div>

        </div>
        <div class="col-sm-4">
        </div>
    </div>
</div>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</html>