<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light">


    <div class="main">
    <form action="create.php" method="POST" enctype="multipart/form-data">
        <label for="">Name:</label>
        <input type="text" name="name"><br>
        <label for="">Value:</label>
        <input type="text" name="value" id=""><br>
        <label for="">Image:</label>
        <input type="file" name="image" id=""><br>

        <button type="submit" name="upload" class='btn btn-primary m-2'>Upload</button>

    </form>


    </div>
<div class="container">


    <table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Value</th>
      <th scope="col">Image</th>
 
      <a hr="">
    </tr>
  </thead>
  <tbody>


  <?php
  include 'crudconfig.php';

  $fetch = mysqli_query($con, "select * from product");

  while($row = mysqli_fetch_array($fetch)){
    echo "
    <tr>
      <td>$row[Id]</td>
      <td>$row[Name]</td> 
      <td>$row[Value]</td>
      <td><img src='$row[Image]' width = '230px' height = '120px'></td>
    </tr>
    ";
  }
  ?>
  </tbody>
</table>
</div>


</body>
</html>


